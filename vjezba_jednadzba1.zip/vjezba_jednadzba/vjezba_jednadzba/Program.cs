﻿using System;

namespace vjezba_jednadzba
{
    
    class Program
    {
        static void Main(string[] args)
        {
            var jednadzba = new jednadzba();
            Console.WriteLine("Zadatak jednadzba");
            jednadzba.seta(1);
            jednadzba.setb(3);
            jednadzba.setc(5);
            jednadzba.setx(0);
            jednadzba.sety(0);
            //Console.WriteLine("Podaci su:");
            //Console.WriteLine(jednadzba.a);
            //Console.WriteLine(jednadzba.b);
            //Console.WriteLine(jednadzba.c);
            //Console.WriteLine(jednadzba.x);
            //Console.WriteLine(jednadzba.y);

            jednadzba j1 = new jednadzba();
            j1.PostaviParametre(1, -1, -1, 1, 1 ,25);
            double r1 = j1.RjesenjeR1();
            double r2 = j1.RjesenjeR2();

            Console.WriteLine("Rjesenje1: {0}" + "Rjesenje 2: {1}", r1, r2);


        }
    }

}
