﻿using System;
using System.Collections.Generic;
using System.Text;

namespace vjezba_jednadzba
{
    public class jednadzba
    {
        public double a;
        public double b;
        public double c;
        public double d;
        public double e;
        public double f;
        public double x;
        public double y;


        //metode za postavljanje
        public void PostaviParametre(double a, double b, double c, double d, double e, double f)
        {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
            this.f = f;
            
        }
        //metoda za izracun
        public double RjesenjeR1()
        {         
            double rjesenje = (c * e) - (b * f) / (a * e) - (b * d);
            return rjesenje;
        }
        public double RjesenjeR2()
        {
            double rjesenje = (a * f) - (c * d) / (a * e) - (b * d);
            return rjesenje;
        }

        public void seta(double _a)
        {
            a = _a;
        }
        public void setb(double _b)
        {
            b = _b;
        }
        public void setc(double _c)
        {
            c = _c;
        }
        public void setd(double _d)
        {
            d = _d;
        }
        public void setf(double _f)
        {
            f = _f;
        }
        public void setx(double _x)
        {
            x = _x;
        }
        public void sety(double _y)
        {
            y = _y;
        }

        
        public double geta()
        {
            return a;
        }
        public double getb()
        {
            return b;
        }
        public double getc()
        {
            return c;
        }
        public double getd()
        {
            return d;
        }
        public double getf()
        {
            return f;
        }
        public double getx()
        {
            return x;
        }
        public double gety()
        {
            return y;
        }
    }
}
