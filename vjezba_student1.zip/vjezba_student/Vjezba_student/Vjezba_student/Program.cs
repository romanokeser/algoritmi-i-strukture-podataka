﻿using System;

namespace Vjezba_student
{
     
    class Program
    {
        static void Main(string[] args)
        {
            var student = new Student();
            student.setIme("Pero");
            student.setPrezime("Peric");
            student.setJMBAG(123131);
            student.setJMBG(7845121);
            student.setGodinaStudija(2);
            student.setOstvareniECTSBodovi(68);
             
            Console.WriteLine(student.Ime);
            Console.WriteLine(student.Prezime);
            Console.WriteLine(student.JMBG);
            Console.WriteLine(student.JMBAG);
            Console.WriteLine(student.OIB);
            Console.WriteLine(student.GodinaStudija);
            Console.WriteLine(student.OstvareniECTSBodovi);
        }
    }
}





