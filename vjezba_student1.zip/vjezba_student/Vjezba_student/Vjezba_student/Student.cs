﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vjezba_student
{
    public class Student
    {
        public string Ime;
        public string Prezime;
        public int JMBG;
        public int JMBAG;
        public int OIB;
        public int GodinaStudija;
        public int OstvareniECTSBodovi;

        //public Student(string _ime, string _prezime, int _JMBG, int _jMBAG, int _OIB, int _GodinaStudija, int _OstvareniECTSBodovi)
        //{
        //    this.Ime = _ime;
        //    this.Prezime = _prezime;
        //    this.JMBG = _JMBG;
        //    this.JMBAG = _jMBAG;
        //    this.OIB = _OIB;
        //    this.GodinaStudija = _GodinaStudija;
        //    this.OstvareniECTSBodovi = _OstvareniECTSBodovi;
        //}

        
        public void setIme( string _Ime)
        {
            Ime = _Ime;
        }
        public void setPrezime(string _Prezime)
        {
            Prezime = _Prezime;
        }

        public void setJMBAG(int _JMBAG)
        {
            JMBAG = _JMBAG;
        }
        public void setJMBG(int _JMBG)
        {
            JMBG = JMBG;
        }
        public void setOIB(int _OIB)
        {
            OIB = _OIB;
        }
        public void setGodinaStudija(int _GodinaStudija)
        {
            GodinaStudija = _GodinaStudija;
        }
        public void setOstvareniECTSBodovi(int _OstvareniECTSBodovi)
        {
            OstvareniECTSBodovi = _OstvareniECTSBodovi;
        }

        public string getIme()
        {
            return Ime;
        }
        public string getprezime()
        {
            return Prezime;
        }
        public int getJMBG()
        {
            return JMBG;
        }
        public int getJMBAG()
        {
            return JMBAG;
        }
        public int getOIB()
        {
            return OIB;
        }
        public int getGodinaStudija()
        {
            return GodinaStudija;
        }
        public int getOstvareniECTSBodovi()
        {
            return OstvareniECTSBodovi;
        }

        
    }
}

