﻿using System;

namespace zad_2
{
    class Program
    {
        static void Main(string[] args)
        {
            

        }
    }
}
