﻿using System;
using System.Collections.Generic;
using System.Text;


public class Racunalo
{
    private string CPU { get; set; }
    private string GPU { get; set; }
    private string MEM { get; set; }
    private string DISK { get; set; }
    private int MemGB { get; set; }
    private int NAPAJANJE { get; set; }

    public void setCPU(string cpu)
    {
        cpu = cpu;
    }

    public void setGPU(string gpu)
    {
        GPU = gpu;
    }

    public void setMEM(string mem)
    {
        MEM = mem;
    }

    public void setDISK(string disk)
    {
        DISK = disk;
    }

    public void setMemGB(int memgb)
    {
        MemGB = memgb;
    }

    public void setNAPAJANJE(int napajanje)
    {
        NAPAJANJE = napajanje;
    }

    public string getCPU()
    {
        return CPU;
    }

    public string getDISK()
    {
        return DISK;
    }
    public string getGPU()
    {
        return GPU;
    }

    public string getMEM()
    {
        return MEM;
    }

    public int getMemGB()
    {
        return MemGB;
    }

    public int getNAPAJANJE()
    {
        return NAPAJANJE;
    }

}
