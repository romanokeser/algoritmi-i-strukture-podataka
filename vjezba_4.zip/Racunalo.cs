﻿using System;
using System.Collections.Generic;
using System.Text;


namespace ConsoleApp2
{
    public class Racunalo
    {
        private string CPU;
        private string GPU;
        private string MB;
        private string DISK;
        private string POWER;
        private string RAM;


        public void setCPU(string cpu)
        {
            CPU = cpu;
        }

        public void setGPU(string gpu)
        {
            GPU = gpu;
        }

        public void setMB(string mb)
        {
           MB = mb;
        }

        public void setDISK(string disk)
        {
               DISK = disk;
           
        }

        public void setPOWER(string pow)
        {
            POWER = pow;
        }
        public void setRAM(string ram)
        {
            RAM = ram;
        }

        public string getCPU()
        {
            return CPU;
        }

        public string getDISK()
        {
            return DISK;
        }

        public string getPOWER()
        {
            return POWER;
        }

        public string getRAM()
        {
            return RAM;
        }

        public string getMB()
        {
            return MB;
        }
        public string getGPU()
        {
            return GPU;
        }


        public string toString()
        {
   
            return ("CPU: " + getCPU() + "\n" + "RAM: " + getRAM() + "\n" + "GPU: " + getGPU() + "\n" + "DISK: " + getDISK() + "\n" + "Napajanje: " + getPOWER() + "\n" + "Motherboard: " + getMB() + "\n");
        }
    }
}
