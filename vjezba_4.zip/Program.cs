﻿using System;
using System.Collections.Generic;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Racunalo

            Racunalo a = new Racunalo();

            a.setCPU("2.3GHz Intel Core i5-8300H (quad-core, 8MB cache, up to 4.00GHz with Turbo Boost)");
            a.setRAM("8GB DDR4(2, 666MHz)");
            a.setDISK("128GB SSD(PCIe); \n  1TB HDD(5,400 rpm)");
            a.setPOWER("135W AC Charger");
            a.setMB("Gigabyte Z390 Aorus Pro Wifi");
            a.setGPU("Intel UHD Graphics 630; \n  Nvidia GeForce GTX 1050 Ti (4GB GDDR5)");

            Racunalo b = new Racunalo();

            b.setCPU("Intel Core i7-9700K");
            b.setRAM("G.Skill TridentZ RGB 2x8GB DDR4 - 3200");
            b.setDISK("Samsung 970 Evo 1TB");
            b.setPOWER("Corsair RM850x 850W");
            b.setMB("Gigabyte Z390 Aorus Ultra");
            b.setGPU("Nvidia GeForce RTX 2080 Super 8GB");

            List<Racunalo> popisRacunala = new List<Racunalo>();

            popisRacunala.Add(a);
            popisRacunala.Add(b);

            Console.Write(a.toString());
            Console.Write("\n");
            Console.Write(b.toString());

            // Kocka

            Console.WriteLine("\n<----------------------------->");

            Kocka k1 = new Kocka();

            k1.setpovrsina(5);
            k1.setvolumen(5);

            Console.WriteLine(k1.toString1());
        }


    }
}