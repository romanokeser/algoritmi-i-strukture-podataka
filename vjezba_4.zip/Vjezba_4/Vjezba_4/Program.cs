﻿using System;

namespace Vjezba_4
{
    class Kocka
    {
        static void Main(string[] args)
        {
            var a = 5;
            var volumen = Math.Pow(a, 3);
            var oplosje = 6 * Math.Pow(a, 2);
            Console.WriteLine($"Volumen kocke iznosi: {volumen}");
            Console.WriteLine($"Oplosje kocke iznosi: {oplosje}");
            Console.ReadKey();
        }
    }

    
}
